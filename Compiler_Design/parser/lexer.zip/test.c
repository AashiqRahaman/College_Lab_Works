int main() {
    int x;
    x = 10;
    if (x > 5) {
        x = x + 1-;
    } else {
        x = x++ ;
    }
    return x;
}
